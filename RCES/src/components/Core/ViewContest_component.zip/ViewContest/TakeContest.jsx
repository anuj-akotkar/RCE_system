import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import QuestionPanel from "./QuestionPanel";
import CodeEditor from "./CodeEditor";
import OutputPanel from "./OutputPanel";
import { contestEndpoints } from "../../../services/apis";
import { apiConnector } from "../../../services/apiconnector";
import { runCode, submitCode } from "../../../services/operations/codeAPI";

const { GET_FULL_CONTEST_DETAILS_API } = contestEndpoints;

const TakeContest = () => {
  const { contestName, contestId } = useParams();
  const [questions, setQuestions] = useState([]);
  const [selected, setSelected] = useState(null);
  const [output, setOutput] = useState(null);
  const [loading, setLoading] = useState(false);
  const { token } = useSelector((state) => state.auth);

  useEffect(() => {
    const fetchQuestions = async () => {
      setLoading(true);
      try {
        const res = await apiConnector(
          "GET",
          `${GET_FULL_CONTEST_DETAILS_API}/${contestId}`,
          null,
          { Authorization: `Bearer ${token}` }
        );
        const contestQuestions = res.data?.contest?.questions || [];
        setQuestions(contestQuestions);
        if (contestQuestions.length > 0) {
          setSelected(contestQuestions[0]);
        }
      } catch (error) {
        console.error("Failed to fetch contest details:", error);
      }
      setLoading(false);
    };
    fetchQuestions();
  }, [contestId, token]);

  // ✅ CORRECTED: These functions now accept 'code' and 'language' from the child.
  const handleRun = async (code, language) => {
    if (!selected) return;
    setLoading(true);
    setOutput(null); // Clear previous output
    try {
      const result = await runCode({
        language,
        code,
        questionId: selected._id,
        token,
      });
      setOutput(result);
    } catch (err) {
      console.error("Run code error:", err);
      setOutput({
        success: false,
        message: err.message || "Failed to run code",
      });
    }
    setLoading(false);
  };

  const handleSubmit = async (code, language) => {
    if (!selected) return;
    setLoading(true);
    setOutput(null); // Clear previous output
    try {
      const result = await submitCode({
        language,
        code,
        questionId: selected._id,
        token,
      });
      setOutput(result);
    } catch (err) {
      console.error("Submit code error:", err);
      setOutput({
        success: false,
        message: err.message || "Failed to submit code",
      });
    }
    setLoading(false);
  };

  return (
    <div className="flex h-[calc(100vh-3.5rem)] bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      {/* Left: Question Panel */}
      <div className="w-1/2 border-r border-gray-200 dark:border-gray-700 p-4 overflow-y-auto">
        <QuestionPanel
          questions={questions}
          selectedQuestion={selected}
          onSelectQuestion={setSelected}
        />
      </div>
      {/* Right: Code Editor and Output */}
      <div className="w-1/2 flex flex-col p-4">
        <div className="flex-grow">
          {/* ✅ CORRECTED: Removed language and setLanguage props */}
          <CodeEditor
            onRun={handleRun}
            onSubmit={handleSubmit}
            loading={loading}
            questionName={selected?.title}
            questionId={selected?._id}
            contestId={contestId}
            contestName={contestName}
            token={token}
          />
        </div>
        <div className="flex-shrink-0 mt-4 h-1/3">
          <OutputPanel output={output} />
        </div>
      </div>
    </div>
  );
};

export default TakeContest;
