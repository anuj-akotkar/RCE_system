print("Hello from Python!")
