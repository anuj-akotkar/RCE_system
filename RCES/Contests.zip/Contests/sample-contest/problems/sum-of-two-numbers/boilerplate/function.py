def sum(a, b):
    # Implementation goes here
    pass