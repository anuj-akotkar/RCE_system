int sum(int a, int b) {
    // Implementation goes here
    return 0;
}