import java.util.*;
import java.io.*;

public class Solution {
    // USER CODE HERE
    public static int sum(int a, int b) {
        // Implementation goes here
        return 0;
    }
    
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        
        int a = scanner.nextInt();
        int b = scanner.nextInt();

        
        int result = sum(a, b);
        
        System.out.println(result);
        
        scanner.close();
    }
}