# USER CODE HERE
def sum(a, b):
    # Implementation goes here
    pass

if __name__ == "__main__":
    a = int(input())
    b = int(input())

    
    result = sum(a, b)
    
    print(result)