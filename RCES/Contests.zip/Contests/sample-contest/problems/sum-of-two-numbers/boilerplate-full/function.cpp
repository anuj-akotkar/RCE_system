#include <iostream>
using namespace std;

// USER CODE HERE
int sum(int a, int b) {
    // Implementation goes here
    return 0;
}

int main() {
    int a;
    cin >> a;
    int b;
    cin >> b;

    
    int result = sum(a, b);
    
    cout << result << endl;
    
    return 0;
}