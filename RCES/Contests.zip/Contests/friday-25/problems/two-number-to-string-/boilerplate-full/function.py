# USER CODE HERE
def sumstring("frist", "second"):
    # Implementation goes here
    pass

if __name__ == "__main__":
    "frist" = input().strip()
    "second" = input().strip()

    
    result = sumstring("frist", "second")
    
    print(result)