#include <iostream>
#include <string>
using namespace std;

// USER CODE HERE
int sumstring(string "frist", string "second") {
    // Implementation goes here
    return 0;
}

int main() {
    string "frist";
    cin >> "frist";
    string "second";
    cin >> "second";

    
    int result = sumstring("frist", "second");
    
    cout << result << endl;
    
    return 0;
}