import java.util.*;
import java.io.*;

public class Solution {
    // USER CODE HERE
    public static int sumstring(String "frist", String "second") {
        // Implementation goes here
        return 0;
    }
    
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        
        String "frist" = scanner.next();
        String "second" = scanner.next();

        
        int result = sumstring("frist", "second");
        
        System.out.println(result);
        
        scanner.close();
    }
}