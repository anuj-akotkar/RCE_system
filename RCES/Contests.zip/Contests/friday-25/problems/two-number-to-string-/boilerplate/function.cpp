int sumstring(string "frist", string "second") {
    // Implementation goes here
    return 0;
}