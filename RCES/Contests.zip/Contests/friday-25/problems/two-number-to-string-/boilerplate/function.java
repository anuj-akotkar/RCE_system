public static int sumstring(String "frist", String "second") {
    // Implementation goes here
    return 0;
}