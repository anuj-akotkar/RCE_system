def sumstring("frist", "second"):
    # Implementation goes here
    pass