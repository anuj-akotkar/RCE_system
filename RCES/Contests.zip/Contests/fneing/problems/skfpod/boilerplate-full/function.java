import java.util.*;
import java.io.*;

public class Solution {
    // USER CODE HERE
    public static int twostring(String p1, String p2) {
        // Implementation goes here
        return 0;
    }
    
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        
        String p1 = scanner.next();
        String p2 = scanner.next();

        
        int result = twostring(p1, p2);
        
        System.out.println(result);
        
        scanner.close();
    }
}