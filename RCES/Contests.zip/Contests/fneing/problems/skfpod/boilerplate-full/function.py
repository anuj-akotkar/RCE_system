# USER CODE HERE
def twostring(p1, p2):
    # Implementation goes here
    pass

if __name__ == "__main__":
    p1 = input().strip()
    p2 = input().strip()

    
    result = twostring(p1, p2)
    
    print(result)