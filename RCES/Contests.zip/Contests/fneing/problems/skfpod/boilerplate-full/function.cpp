#include <iostream>
#include <string>
using namespace std;

// USER CODE HERE
int twostring(string p1, string p2) {
    // Implementation goes here
    return 0;
}

int main() {
    string p1;
    cin >> p1;
    string p2;
    cin >> p2;

    
    int result = twostring(p1, p2);
    
    cout << result << endl;
    
    return 0;
}