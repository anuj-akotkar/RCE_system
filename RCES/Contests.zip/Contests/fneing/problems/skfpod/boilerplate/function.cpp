int twostring(string p1, string p2) {
    // Implementation goes here
    return 0;
}