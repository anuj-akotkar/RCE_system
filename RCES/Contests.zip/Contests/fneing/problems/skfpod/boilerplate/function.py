def twostring(p1, p2):
    # Implementation goes here
    pass