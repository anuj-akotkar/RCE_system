public static int twostring(String p1, String p2) {
    // Implementation goes here
    return 0;
}